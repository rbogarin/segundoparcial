﻿using Repository.Contexts;
using Repository.Entidades;

namespace Repository.Repository.Referenciales
{
    public class FacturaRepository
    {
        private readonly ContextoAplicacionDB _contexto;
        private double total;
        private string total_letras;
        private object total_iva10;
        private object total_iva5;
        private string nro_factura;

        public FacturaRepository(ContextoAplicacionDB contexto)
        {
            _contexto = contexto;
        }

        public bool Agregar(int Id, int? Id_cliente, string Fecha_Hora, string Total, string Total_iva_5, string?Total_iva_10, string? Total_Iva, string? Total_Letras, string Sucursal, bool resultado)
        {
            factura cliente = new factura()
            {
                //FechaHora = Fecha_Hora, 
                NroFactura = nro_factura,
                Total = total,
                Total_iva5 = total_iva5,
                Total_Iva10 = total_iva10,
                TotalLetras = total_letras,
                Sucursal = Sucursal,


            };


            Microsoft.EntityFrameworkCore.ChangeTracking.EntityEntry<Cliente> entityEntry = _contexto.Clientes.Add(cliente);
            int resultado = _contexto.SaveChanges();

            return resultado;
        }
    }
}

