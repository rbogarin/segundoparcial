﻿namespace Repository.Entidades;

public class Persona
{
    /*
     *  -- Id int - pk - autoincremental
        -- Nombre - text
        -- AnhoNacimiento - int
     */

    public int Id { get; set; }
    public string Nombre { get; set; } = "";
    public string Apellido { get; set; } = "";
    public string Cedula{ get; set; } = "";
    public string Celular { get; set; } = "";

    //Relaciones
    public ICollection<factura> Facturas { get; set; }
}
