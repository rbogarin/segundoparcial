﻿namespace Repository.Models;

public class CuentaModelo
{
    public int Id { get; set; }
    public string NumeroCuenta { get; set; } = "";
    public int SaldoActual { get; set; }
}
